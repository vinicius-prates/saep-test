import {generate, parse, transform, stringify} from 'csv';
import sqlite3 from 'sqlite3';
import http from 'http';
import fs from 'fs';
import express from 'express';
import cors from 'cors';

const app = express();
app.use(cors());

const db = new sqlite3.Database('./db.sqlite');
const hostname = '127.0.0.1';
const port = 3000;

// const server = http.createServer((req, res) => {
//   res.statusCode = 200;
//   res.setHeader('Content-Type', 'text/plain');
//   res.end('Hello World');
// });

// server.listen(port, hostname, () => {
//   console.log(`Server running at http://${hostname}:${port}/`);
// });



app.get('/automoveis', (req, res) => {
    console.log("caiu aqui")
    var sql = "SELECT * from Automoveis";

    // Print the records as JSON
    db.serialize(() => {
        // db.each("SELECT rowid AS id, info FROM lorem", (err, row) => {
        //     console.log(row.id + ": " + row.info);
        // });
        db.all(sql, function(err, rows) {
          var jsondata = (JSON.stringify(rows));  
          //send a JSON response
          res.setHeader("Content-Type", "application/json; charset=UTF-8");
          res.writeHead(200);
          res.end(jsondata);
        //   db.close();
         });
    })
        
});

app.get('/automovel/:id', (req, res) => {
    var sql = "SELECT * FROM automoveis where id = " + req.params.id;
    db.serialize(() => {
        db.all(sql, function(err, rows) {
          var jsondata = (JSON.stringify(rows));  
          //send a JSON response
          res.setHeader("Content-Type", "application/json; charset=UTF-8");
          res.writeHead(200);
          res.end(jsondata);
        //   db.close();
         });
    })
})

const retornaAutomoveis = () => {
}

const importar = () => {
    fs.createReadStream("./dados/automoveis.csv")
    .pipe(parse({ delimiter: ";", from_line: 2 }))
    .on("data", function (row) {
        db.serialize(function () {
            db.run(
            `INSERT INTO Automoveis VALUES (null, ?, ?)`,
            [row[1], row[2]],
            function (error) {
                if (error) {
                return console.log(error.message);
                }
                console.log(`Inserted a row with the id: ${this.lastID}`);
            }
            );
        });
        // console.log(row);
        // console.log(row[1]);
    })
    // db.close();
}

app.set('port', process.env.PORT || 5000);
app.listen(app.get('port'), () => {
  console.log('rodando na porta ', app.get('port'));
})

